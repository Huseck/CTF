---
####Usage : 
```
Usage : 
        python SourceLeakHackerForLinux.py [URL]
Example : 
        python SourceLeakHackerForLinux.py http://www.baidu.com/
Tips : 
        Your URL should must starts with "http://" or "https://"
        If you have any questions, please contact [ wangyihanger@gmail.com ]
```

---
####Demos : 
> Windows Usage

![Paste_Image.png](http://upload-images.jianshu.io/upload_images/2355077-78c8d974ae89cea7.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

> Windows Demo

![Paste_Image.png](http://upload-images.jianshu.io/upload_images/2355077-30574de858402b73.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

> Linux Usage

![Paste_Image.png](http://upload-images.jianshu.io/upload_images/2355077-0a7174b2140a2b9a.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

> Linux Demo

![Paste_Image.png](http://upload-images.jianshu.io/upload_images/2355077-890cc733b9643cfa.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

